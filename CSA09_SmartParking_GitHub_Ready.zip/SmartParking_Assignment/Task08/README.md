# Task 8: Polymorphism

Runtime polymorphism: Vehicle v = new ElectricVehicle("EV1","Visitor"); v.calculateFee(60) dispatches to ElectricVehicle.calculateFee, returning 2500 paise. Interface checking: if (v instanceof Chargeable) { int surcharge=((Chargeable)v).chargingSurchargePaise(); }. Compile-time overload example: log(Vehicle v) and log(Vehicle v, boolean detailed) can differ by parameter list. ParkingFacility() and ParkingFacility(int floors) are constructor overloading. Java chooses overload signatures at compile-time, while overrides are dispatched at runtime. The mentioned Vehicle/FeeDemo source snippet was not included, so the supplementary FeeDemo file demonstrates these concepts independently.

See `../src/` for the runnable implementation and `../tests/` for validation.
