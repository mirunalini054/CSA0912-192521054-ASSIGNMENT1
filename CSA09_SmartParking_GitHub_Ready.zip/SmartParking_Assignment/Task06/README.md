# Task 6: Inheritance Hierarchy and Constructor Order

Vehicle is abstract. TwoWheeler extends Vehicle; Car extends Vehicle; ElectricVehicle extends Car and implements Chargeable. Constructors execute superclass constructors before subclass bodies. Example new ElectricVehicle("EV1","Visitor"): Object constructor -> Vehicle(String,String) -> Car(String,String) -> ElectricVehicle(String,String). User roles (student/staff/visitor) are stored as owner labels in this minimal demonstrator; a dedicated User superclass and role subclasses are a proposed extension if distinct permissions or discounts are required. See UML diagram for the implemented vehicle hierarchy.

See `../src/` for the runnable implementation and `../tests/` for validation.
