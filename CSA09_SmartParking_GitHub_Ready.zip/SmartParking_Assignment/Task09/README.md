# Task 9: Abstraction

abstract class Vehicle provides shared validated identity and abstract category()/hourlyRatePaise() contracts. interface Chargeable declares chargingSurchargePaise(); ElectricVehicle implements it. interface Payable declares calculateFee(long) and can be implemented by payment-capable services; the project includes the interface as the required abstraction without falsely claiming every vehicle implements it. Optional improvement: have Vehicle implement Payable, ensuring one consistent billing contract through the interface.

See `../src/` for the runnable implementation and `../tests/` for validation.
