# Task 11: Testing and Defence

Compile: javac -d out $(find src -name '*.java') tests/ParkingTest.java. Run: java -cp out ParkingTest. Execute application: java -cp out parking.app.Main. Verified 14 checks: floor capacity=10; compatible allocation; occupancy increment; duplicate reject; bike 1 min=Rs10; occupancy decrement; car 61 min=Rs40; EV 60 min=Rs25; valid pass=Rs0; reject exit before entry; failed exit retains slot; car zero duration=Rs20 minimum; full bike section rejected; case-insensitive plate equals. Manual comparison: bike 1 minute -> ceil(1/60)=1 -> Rs10; car 61 minutes -> ceil(61/60)=2 -> Rs40; EV 60 minutes -> 1*Rs20 + Rs5 -> Rs25. Execution tested against Java 21. Notes: data resides in memory and does not persist across runs; timestamps use local time, and concurrency is not supported.

See `../src/` for the runnable implementation and `../tests/` for validation.
