# Task 4: Classes, Objects and Constructors

Vehicle is an abstract superclass with a parameterized constructor and copy constructor. ParkingFacility offers overloaded constructors: ParkingFacility() chains to ParkingFacility(2); ParkingFacility(int floors) configures floor count. Slot, Ticket and Pass use validating parameterized constructors. A compiler-provided default constructor is not generated when a custom constructor is declared; a no-argument constructor has been defined explicitly where useful. Constructor chaining uses this(2) in ParkingFacility and super(plate,owner) in subclasses. Conceptually local references live on stack frames while objects are allocated on the managed heap; JVM implementation optimizations may differ. Examples: new Car("TN01AA1234","Student"); new ParkingFacility(); new ParkingFacility(5).

See `../src/` for the runnable implementation and `../tests/` for validation.
