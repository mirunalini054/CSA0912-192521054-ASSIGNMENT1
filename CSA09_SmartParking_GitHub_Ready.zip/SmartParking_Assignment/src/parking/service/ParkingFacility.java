package parking.service;
import parking.model.*;
import java.time.*;
import java.util.*;
public class ParkingFacility {
    private final List<Slot> slots = new ArrayList<>();
    private final Map<String, Ticket> active = new HashMap<>();
    private final Map<String, Pass> passes = new HashMap<>();
    private static int totalEntries = 0;
    public ParkingFacility(int floors) {
        if (floors < 1 || floors > 20) throw new IllegalArgumentException("Floors must be 1 to 20");
        for (int f=1; f<=floors; f++) {
            int n=1;
            for (int i=0;i<4;i++) slots.add(new Slot(f,n++,"TWO_WHEELER"));
            for (int i=0;i<4;i++) slots.add(new Slot(f,n++,"CAR"));
            for (int i=0;i<2;i++) slots.add(new Slot(f,n++,"ELECTRIC"));
        }
    }
    public ParkingFacility() { this(2); }
    public void addMonthlyPass(String plate, LocalDate validThrough) {
        passes.put(plate.trim().toUpperCase(), new Pass(plate,validThrough));
    }
    public Ticket enter(Vehicle vehicle, LocalDateTime entry) {
        Objects.requireNonNull(vehicle); Objects.requireNonNull(entry);
        if (active.containsKey(vehicle.getPlate())) throw new IllegalStateException("Vehicle already parked");
        for (Slot slot: slots) {
            if (slot.isAvailable() && slot.getType().equals(vehicle.category())) {
                slot.occupy(vehicle.getPlate());
                Ticket ticket = new Ticket(vehicle, slot, entry);
                active.put(vehicle.getPlate(),ticket); totalEntries++; return ticket;
            }
        }
        throw new IllegalStateException("No compatible parking slot available");
    }
    public long exit(String plate, LocalDateTime exit) {
        Objects.requireNonNull(plate); Objects.requireNonNull(exit);
        String key = plate.trim().toUpperCase();
        Ticket ticket = active.get(key);
        if (ticket == null) throw new IllegalArgumentException("Vehicle not parked");
        long mins = Duration.between(ticket.getEntry(), exit).toMinutes();
        if (mins < 0) throw new IllegalArgumentException("Exit before entry");
        Pass pass = passes.get(key);
        long fee = pass != null && pass.validFor(key, exit.toLocalDate()) ? 0 : ticket.getVehicle().calculateFee(mins);
        active.remove(key); ticket.getSlot().release(); return fee;
    }
    public int occupancy() { return active.size(); }
    public int capacity() { return slots.size(); }
    public static int getTotalEntries() { return totalEntries; }
    public List<Slot> getSlots() { return Collections.unmodifiableList(slots); }
    public static String rupees(long paise) { return String.format(java.util.Locale.ROOT,"Rs. %d.%02d",paise/100, paise%100); }
}
