# Task 10: Encapsulation and Packages

Package layout: parking.model contains Vehicle, subclasses, Slot, Ticket, Pass, Chargeable, Payable; parking.service contains ParkingFacility; parking.app contains Main; tests contains ParkingTest. Fields are private/final where possible, and callers access data through getters. Constructors validate nonblank plates/owners, floor bounds, allowed slot categories and pass dates; entry rejects duplicate plates and unavailable slots; exit rejects missing vehicles and timestamps before entry. The read-only slot list prevents callers from changing list membership. For stricter encapsulation, expose only immutable snapshots instead of mutable Slot references.

See `../src/` for the runnable implementation and `../tests/` for validation.
