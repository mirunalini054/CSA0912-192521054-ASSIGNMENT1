# Campus Smart-Parking System – CSA09 Assignment 1

**Repository:** CSA0912-192521054-ASSIGNMENT1  
**Register number:** 192521054  
**Student name:** [Enter your official name]  
**Java version tested:** OpenJDK 21  
**Course:** Object-Oriented Java / CSA09 (verify official course code)

## Functional demonstration
Two floors by default, 4 bike + 4 car + 2 EV charging-compatible bays on each floor. Vehicle entry allocates the first free slot of the matching category, and exit rounds elapsed parking duration up to the next hour, minimum one hour. An active monthly pass waives the exit charge. UI options: Enter, Exit, Status, Monthly pass, Quit.

**Illustrative policy assumptions (not stated in the supplied task overview):** bikes Rs10 per hour, cars Rs20 per hour, EVs Rs20 per hour plus a Rs5 fixed charging-capable parking surcharge. A pass is free in this demo (purchase/billing omitted). These can be adjusted once faculty's exact tariff table is available. Times are entered automatically using system clock in the menu, and injected in tests for reproducibility.

## Compile and run from repository root
```bash
mkdir -p out
javac -d out $(find src -name '*.java') tests/ParkingTest.java
java -cp out ParkingTest
java -cp out parking.app.Main
java -cp out parking.app.FeeDemo
```
Windows PowerShell:
```powershell
New-Item -ItemType Directory -Force out
javac -d out (Get-ChildItem -Recurse src -Filter *.java | ForEach-Object FullName) tests/ParkingTest.java
java -cp out ParkingTest
java -cp out parking.app.Main
```

## Structure
`Task01` through `Task12`: rubric-aligned task notes. `src/parking/model`: domain and interfaces. `src/parking/service`: allocation and billing. `src/parking/app`: interactive console and polymorphism demo. `tests/ParkingTest.java`: automated checks. `diagrams`: class and process visuals. `Report.pdf`: printable narrative and evidence.

## Sample expected test output
`ALL 14 TESTS PASSED` (verified on Java 21).

## Key limitations / next improvements
This is an in-memory academic demonstrator, not a production reservation service. No database, login, concurrency control, audit log or external payment gateway. EV charging is modeled as a dedicated slot with fixed surcharge, not metered energy consumption. Some rubric tasks refer to **provided code snippets** that were not supplied here; original working equivalents are provided instead. Some requirements for users, van pricing and passes are discussed as design extensions rather than implemented end-to-end.

## Academic submission
Review, modify, and be prepared to explain your own design. Make genuine incremental commits as you work through the 12 task folders. Uploading a ZIP in one GitHub commit does **not** satisfy a progressive-commit requirement. Do not fabricate earlier commit dates.
