# Task 2: Data Representation

The model uses String for plates and names, int for floor/slot/rate paise, long for minutes and fee totals, LocalDateTime for entry/exit, LocalDate for passes, boolean for availability. Money is stored as whole paise in long to avoid floating-point rounding; never cast double to int for billing. Duration.between(...).toMinutes() returns long, and checked multiplication detects overflow. A 1D List<Slot> is used: each Slot stores a floor identifier; this is flexible for differing floor capacities. A jagged Slot[][] array would also allow different floors to have different numbers of spaces but requires explicit bounds and resizing. The model never casts superclass Vehicle references to subclasses without type checks.

See `../src/` for the runnable implementation and `../tests/` for validation.
